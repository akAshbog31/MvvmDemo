//
//  APICall.swift
//  mvvmdemo
//
//  Created by mac on 19/10/22.
//

import Foundation
import Moya

protocol Networkable {
    var provider: MoyaProvider<Mvvm> { get }
    
    func getData(complition: @escaping (Result<MainModel,Error>) -> Void)
}

class NetworkManager: Networkable {
    var provider = MoyaProvider<Mvvm>(plugins: [NetworkLoggerPlugin(configuration: .init(formatter: .init(), output: { target, items in
        if let log = items.first {
            print(log)
        }
    }, logOptions: .formatRequestAscURL))])
    
    func getData(complition: @escaping (Result<MainModel, Error>) -> Void) {
        request(target: .getMemes, complition: complition)
    }
}

extension NetworkManager {
    func request<T: Codable>(target: Mvvm, complition: @escaping (Result<T,Error>) -> Void) {
        provider.request(target) { result in
            switch result {
            case .success(let response):
                do {
                    let results = try JSONDecoder().decode(T.self, from: response.data)
                    complition(.success(results))
                } catch let error {
                    complition(.failure(error))
                }
            case .failure(let error):
                complition(.failure(error))
            }
        }
    }
}
