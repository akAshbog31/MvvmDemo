//
//  DataTableViewCell.swift
//  mvvmdemo
//
//  Created by mac on 18/10/22.
//

import UIKit

class DataTableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    
    func loadData(_ cellModel: DataCellViewModel) {
        lblName.text = cellModel.name
    }
}
