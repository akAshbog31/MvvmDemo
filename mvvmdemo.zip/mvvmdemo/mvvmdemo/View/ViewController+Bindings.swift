//
//  ViewController+Bindings.swift
//  mvvmdemo
//
//  Created by mac on 20/10/22.
//

import UIKit

extension ViewController {
    func bindData() {
        viewModel.isLoading.bind { [weak self] isLoading in
            guard let self = self, let isLoading = isLoading else {return}
            if isLoading {
                self.activityIndicator.startAnimating()
            } else {
                self.activityIndicator.stopAnimating()
            }
        }
        
        viewModel.dataSource.bind { [weak self] mems in
            guard let self = self, let mems = mems else {return}
            self.mems = mems
            DispatchQueue.main.async {
                self.dataTblView.reloadData()
            }
        }
    }
}
