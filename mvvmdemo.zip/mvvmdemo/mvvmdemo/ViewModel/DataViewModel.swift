//
//  DataViewModel.swift
//  mvvmdemo
//
//  Created by mac on 19/10/22.
//

import Foundation

class MainViewModel {
    
    private let networkManager = NetworkManager()
    var isLoading: Obserable<Bool> = Obserable(false)
    var dataSource: Obserable<[DataCellViewModel]> = Obserable([])
    
    func numberOfSection() -> Int {
        1
    }
    
    func numberOfRowInSection(_ section: Int) -> Int {
        return dataSource.value?.count ?? 0
    }
    
    func getData() {
        if isLoading.value ?? true {
            return
        }
        isLoading.value = true
        networkManager.getData { result in
            self.isLoading.value = false
            switch result {
            case .success(let model):
                self.dataSource.value = model.data?.memes?.compactMap({DataCellViewModel(mems: $0)})
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
