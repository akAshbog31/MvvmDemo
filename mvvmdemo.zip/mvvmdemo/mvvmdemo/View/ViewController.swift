//
//  ViewController.swift
//  mvvmdemo
//
//  Created by mac on 14/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var dataTblView: UITableView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var viewModel: MainViewModel = MainViewModel()
    var mems: [DataCellViewModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpTblView()
        bindData()
        viewModel.getData()
    }
}


