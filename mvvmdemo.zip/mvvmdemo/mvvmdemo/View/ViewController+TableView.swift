//
//  ViewController+TableView.swift
//  mvvmdemo
//
//  Created by mac on 20/10/22.
//

import UIKit

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func setUpTblView() {
        dataTblView.delegate = self
        dataTblView.dataSource = self
        dataTblView.register(UINib(nibName: "DataTableViewCell", bundle: nil), forCellReuseIdentifier: "DataTableViewCell")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.numberOfSection()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowInSection(section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = dataTblView.dequeueReusableCell(withIdentifier: "DataTableViewCell", for: indexPath) as? DataTableViewCell else { return .init() }
        guard let cellModel = viewModel.dataSource.value?[indexPath.row] else { return .init() }
        cell.loadData(cellModel)
        return cell
    }
}
