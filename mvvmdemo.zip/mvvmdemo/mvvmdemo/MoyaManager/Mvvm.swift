//
//  Mvvm.swift
//  mvvmdemo
//
//  Created by mac on 29/10/22.
//

import Foundation
import Moya

enum Mvvm {
    case getMemes
}

extension Mvvm: TargetType {
    var baseURL: URL {
        return URL(string: "https://api.imgflip.com/")!
    }
    
    var path: String {
        switch self {
        case .getMemes:
            return "get_memes"
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .getMemes:
            return .get
        }
    }
    
    var task: Task {
        switch self {
        case .getMemes:
            return .requestPlain
        }
    }
    
    var headers: [String : String]? {
        switch self {
        case .getMemes:
            return ["Content-Type": "application/json"]
        }
    }
}
