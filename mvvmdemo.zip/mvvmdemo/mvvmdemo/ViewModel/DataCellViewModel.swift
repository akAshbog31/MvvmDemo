//
//  DataCellViewModel.swift
//  mvvmdemo
//
//  Created by mac on 20/10/22.
//

import UIKit

class DataCellViewModel {
    var name: String
    var url: URL?
    
    init(mems: Mems) {
        self.name = mems.name ?? ""
        self.url = self.getUrl(mems)
    }
    
    func getUrl(_ mems: Mems) -> URL? {
        return URL(string: mems.url ?? "")
    }
}
